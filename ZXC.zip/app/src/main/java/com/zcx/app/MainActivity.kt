package com.zcx.app

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.speech.RecognizerIntent
import android.text.SpannableString
import android.text.style.AbsoluteSizeSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts.GetContent
import androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.*
import androidx.media3.effect.*
import androidx.media3.transformer.*
import androidx.media3.transformer.Composition
import com.google.common.collect.ImmutableList
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

val Bg = Color(0xFF0A0B14); val A1 = Color(0xFF8B5CF6); val A2 = Color(0xFF22D3EE); val A3 = Color(0xFFF472B6)
fun Modifier.glass() = this.background(Color(0x14FFFFFF), RoundedCornerShape(20.dp)).border(1.dp, Color(0x24FFFFFF), RoundedCornerShape(20.dp))

val sty = listOf(
    Triple("Classic", 0xFFFFFFFFL, 0L), Triple("Gold", 0xFFFFD60AL, 0L), Triple("Neon", 0xFF22D3EEL, 0L), Triple("Pink", 0xFFF472B6L, 0L),
    Triple("Box", 0xFFFFFFFFL, 0xCC000000L), Triple("Sun", 0xFF000000L, 0xFFFFD60AL), Triple("Red", 0xFFFFFFFFL, 0xFFE11D48L), Triple("Violet", 0xFFFFFFFFL, 0xFF7C3AEDL),
    Triple("Mint", 0xFF34D399L, 0L), Triple("Sky", 0xFF38BDF8L, 0xAA000000L), Triple("Lime", 0xFFA3E635L, 0L), Triple("Orange", 0xFFFB923CL, 0L),
    Triple("CyanBox", 0xFF000000L, 0xFF22D3EEL), Triple("Rose", 0xFFFDA4AFL, 0xAA000000L), Triple("Ghost", 0xFFFFFFFFL, 0x66000000L), Triple("Blue", 0xFFFFFFFFL, 0xFF2563EBL))
val tn = listOf("Cinema", "Vivid", "Noir", "Warm", "Cool", "Vintage", "Neon", "Dream", "Drama", "Fresh")
val tc = listOf(0xFF1E3A8A to 0xFFB45309, 0xFFEC4899 to 0xFFF59E0B, 0xFF111827 to 0xFF6B7280, 0xFFF97316 to 0xFFFDE047, 0xFF0EA5E9 to 0xFF6366F1,
    0xFF92400E to 0xFFD6B88A, 0xFF7C3AED to 0xFF22D3EE, 0xFFBFDBFE to 0xFFFBCFE8, 0xFF000000 to 0xFFDC2626, 0xFF16A34A to 0xFFA3E635).map { Color(it.first) to Color(it.second) }

fun tplFx(i: Int): List<Effect> = when (i) {
    0 -> listOf<Effect>(Contrast(.25f), HslAdjustment.Builder().adjustSaturation(-10f).build())
    1 -> listOf<Effect>(HslAdjustment.Builder().adjustSaturation(40f).build(), Contrast(.1f))
    2 -> listOf<Effect>(RgbFilter.createGrayscaleFilter())
    3 -> listOf<Effect>(RgbAdjustment.Builder().setRedScale(1.15f).setBlueScale(.85f).build())
    4 -> listOf<Effect>(RgbAdjustment.Builder().setRedScale(.85f).setBlueScale(1.2f).build())
    5 -> listOf<Effect>(HslAdjustment.Builder().adjustSaturation(-35f).build(), RgbAdjustment.Builder().setRedScale(1.1f).setBlueScale(.9f).build())
    6 -> listOf<Effect>(HslAdjustment.Builder().adjustSaturation(80f).build(), Contrast(.3f))
    7 -> listOf<Effect>(Brightness(.12f), HslAdjustment.Builder().adjustSaturation(-15f).build())
    8 -> listOf<Effect>(RgbFilter.createGrayscaleFilter(), Contrast(.5f))
    9 -> listOf<Effect>(RgbAdjustment.Builder().setGreenScale(1.15f).setRedScale(.9f).build(), Contrast(.15f))
    else -> emptyList()
}

class St {
    var video by mutableStateOf<Uri?>(null); var thumb by mutableStateOf<Bitmap?>(null)
    var style by mutableIntStateOf(0); var text by mutableStateOf("Namaste doston"); var tpl by mutableIntStateOf(-1)
    var res by mutableIntStateOf(1080); var sharp by mutableFloatStateOf(0.3f); var smooth by mutableFloatStateOf(0.3f)
    var busy by mutableStateOf(false); var status by mutableStateOf(""); val shorts = mutableStateListOf<File>()
    fun pick(c: Context, u: Uri?) {
        video = u
        if (u != null) thumb = try { val m = MediaMetadataRetriever().apply { setDataSource(c, u) }; val b = m.getFrameAtTime(1000000); m.release(); b } catch (e: Exception) { null }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s); enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = A1, background = Bg, surface = Color(0xFF151728))) {
                var splash by remember { mutableStateOf(true) }
                if (splash) Splash { splash = false } else Root()
            }
        }
    }
}

@Composable fun Splash(done: () -> Unit) {
    val s = remember { Animatable(0.5f) }; val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { launch { s.animateTo(1f, spring(0.45f)) }; a.animateTo(1f, tween(700)); delay(900); done() }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF241552), Bg))), Alignment.Center) {
        Column(Modifier.scale(s.value).alpha(a.value), horizontalAlignment = Alignment.CenterHorizontally) {
            Title("ZXC", 72); Text("CAPTIONS • SHORTS • UPSCALE", color = Color.Gray, fontSize = 11.sp, letterSpacing = 3.sp)
        }
    }
}

@Composable fun Title(t: String, sz: Int) = Text(t, style = TextStyle(brush = Brush.linearGradient(listOf(A1, A2)), fontSize = sz.sp, fontWeight = FontWeight.Black))
@Composable fun Chip(t: String, m: Modifier = Modifier, c: () -> Unit) = Text(t, color = Color.White, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = m.glass().clickable { c() }.padding(14.dp, 10.dp))
@Composable fun Go(t: String, on: Boolean = true, c: () -> Unit) = Box(Modifier.fillMaxWidth().alpha(if (on) 1f else 0.4f).background(Brush.horizontalGradient(listOf(A1, A2)), RoundedCornerShape(16.dp)).clickable(enabled = on) { c() }.padding(16.dp), Alignment.Center) { Text(t, fontWeight = FontWeight.Bold, color = Color.White) }
@Composable fun Status(s: St) { if (s.status.isNotEmpty()) Text(s.status, color = A2) }

@Composable fun Root() {
    val s = remember { St() }; var scr by remember { mutableStateOf("home") }
    BackHandler(scr != "home") { scr = "home" }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1A1040), Bg)))) {
        val back = { scr = "home" }
        when (scr) { "cap" -> CapPage(s, back); "tpl" -> TplPage(s, back); "up" -> UpPage(s, back); "sh" -> ShPage(s, back); else -> Home(s) { scr = it } }
        if (s.busy) Anim(s)
    }
}

@Composable fun Page(t: String, back: () -> Unit, c: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(40.dp).glass().clickable { back() }, Alignment.Center) { Text("‹", fontSize = 24.sp, color = Color.White) }
            Text(t, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
        c()
    }
}

@Composable fun Pick(s: St) {
    val c = LocalContext.current; val l = rememberLauncherForActivityResult(GetContent()) { s.pick(c, it) }
    Box(Modifier.fillMaxWidth().height(if (s.video == null) 150.dp else 90.dp).glass().clickable { l.launch("video/*") }, Alignment.Center) {
        s.thumb?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize().clip(RoundedCornerShape(20.dp)).alpha(0.45f), contentScale = ContentScale.Crop) }
        Text(if (s.video == null) "⬆️  Video upload karo" else "✅ Video ready (badalne ko tap)", color = Color.White, fontWeight = FontWeight.Bold)
    }
}

@Composable fun Player9(u: Uri?, h: Int, ctl: Boolean, over: @Composable BoxScope.() -> Unit = {}) {
    Box(Modifier.height(h.dp).aspectRatio(9f / 16f).clip(RoundedCornerShape(22.dp)).background(Color.Black).border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(22.dp))) {
        if (u != null) AndroidView({ c ->
            FrameLayout(c).apply {
                val v = VideoView(c); addView(v, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
                if (ctl) v.setMediaController(MediaController(c).also { m -> m.setAnchorView(this) }) else v.setOnClickListener { if (v.isPlaying) v.pause() else v.start() }
                v.setOnPreparedListener { p -> p.isLooping = true; v.seekTo(300) }
            }
        }, Modifier.fillMaxSize(), update = { f -> val v = f.getChildAt(0) as VideoView; if (f.tag != u) { f.tag = u; v.setVideoURI(u) } })
        over()
    }
}

@Composable fun Home(s: St, go: (String) -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Title("ZXC", 38); Text("Free • on-device • no credits", color = Color.Gray, fontSize = 12.sp)
        Pick(s)
        listOf(Triple("cap", "💬", "Auto Captions"), Triple("tpl", "🎨", "Templates"), Triple("up", "⬆️", "Upscale"), Triple("sh", "✂️", "Shorts")).chunked(2).forEach { r ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                r.forEach { (k, i, n) -> Column(Modifier.weight(1f).glass().clickable { go(k) }.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(i, fontSize = 36.sp); Text(n, color = Color.White, fontWeight = FontWeight.Bold) } }
            }
        }
        Text("COMING SOON", color = Color.Gray, fontSize = 11.sp, letterSpacing = 2.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Video se auto captions", "Caption animation", "Voice-over", "BG remover", "Beat sync", "AI sharpen (Real-ESRGAN)", "60fps smooth", "Batch export", "Auto best-moment shorts").forEach { Text(it, color = A2, fontSize = 12.sp, modifier = Modifier.glass().padding(12.dp, 8.dp)) }
        }
    }
}

@Composable fun CapText(s: St, m: Modifier) {
    val t = sty[s.style]
    Text(s.text, color = Color(t.second), fontWeight = FontWeight.Bold, fontSize = 16.sp, textAlign = TextAlign.Center,
        modifier = m.background(if (t.third == 0L) Color.Transparent else Color(t.third), RoundedCornerShape(6.dp)).padding(6.dp, 3.dp))
}

@Composable fun CapPage(s: St, back: () -> Unit) {
    val ctx = LocalContext.current
    val vr = rememberLauncherForActivityResult(StartActivityForResult()) { r -> r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { s.text = it } }
    fun listen(l: String) { try { vr.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_LANGUAGE, l)) } catch (e: Exception) { s.status = "Speech app nahi mila" } }
    Page("Auto Captions", back) {
        Pick(s)
        Box(Modifier.fillMaxWidth(), Alignment.Center) { Player9(s.video, 380, true) { CapText(s, Modifier.align(Alignment.BottomCenter).padding(bottom = 56.dp)) } }
        Text("Caption style", color = Color.White, fontWeight = FontWeight.Bold)
        sty.chunked(4).forEachIndexed { ri, row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEachIndexed { ci, t -> val k = ri * 4 + ci
                    Box(Modifier.weight(1f).height(52.dp).background(if (t.third == 0L) Color(0x14FFFFFF) else Color(t.third), RoundedCornerShape(14.dp)).border(if (s.style == k) 2.dp else 0.dp, A2, RoundedCornerShape(14.dp)).clickable { s.style = k }, Alignment.Center) { Text("Aa", color = Color(t.second), fontWeight = FontWeight.Black, fontSize = 18.sp) }
                }
            }
        }
        OutlinedTextField(s.text, { s.text = it }, Modifier.fillMaxWidth(), label = { Text("Caption text (khud likho ya bolo)") })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Chip("🎤 Hindi bolo", Modifier.weight(1f)) { listen("hi-IN") }; Chip("🎤 English bolo", Modifier.weight(1f)) { listen("en-IN") } }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Subscribe karo 🔔", "Part 1", "Wait for end 😮", "Like & Share").forEach { Chip(it) { s.text = it } } }
        Go("CAPTION LAGAO & SAVE", s.video != null && !s.busy) { run(ctx, s, 0) }
        Status(s)
    }
}

@Composable fun TplPage(s: St, back: () -> Unit) {
    val ctx = LocalContext.current
    Page("Templates", back) {
        Pick(s)
        tn.chunked(2).forEachIndexed { ri, row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEachIndexed { ci, n -> val k = ri * 2 + ci
                    Box(Modifier.weight(1f).height(90.dp).background(Brush.linearGradient(listOf(tc[k].first, tc[k].second)), RoundedCornerShape(18.dp)).border(if (s.tpl == k) 3.dp else 0.dp, Color.White, RoundedCornerShape(18.dp)).clickable { s.tpl = if (s.tpl == k) -1 else k }, Alignment.Center) { Text(n, color = Color.White, fontWeight = FontWeight.Bold) }
                }
            }
        }
        Go("TEMPLATE LAGAO & SAVE", s.video != null && s.tpl >= 0 && !s.busy) { run(ctx, s, 3) }
        Status(s)
    }
}

@Composable fun UpPage(s: St, back: () -> Unit) {
    val ctx = LocalContext.current
    Page("Upscale", back) {
        Pick(s)
        Text("Resolution", color = Color.White, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("720p" to 720, "1080p" to 1080, "2K" to 1440, "4K" to 2160).forEach { (n, v) -> FilterChip(s.res == v, { s.res = v }, { Text(n) }) } }
        Text("Sharpness ${(s.sharp * 100).toInt()}%", color = Color.White); Slider(s.sharp, { s.sharp = it })
        Text("Smoothness ${(s.smooth * 100).toInt()}% (AI wala jald aayega)", color = Color.White); Slider(s.smooth, { s.smooth = it })
        Text("Presets", color = Color.White, fontWeight = FontWeight.Bold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(listOf("Balanced", 1080, .3f, .3f), listOf("Crisp", 1440, .6f, .2f), listOf("Cinema", 2160, .4f, .5f), listOf("Social", 1080, .5f, .4f)).forEach { p ->
                Column(Modifier.glass().clickable { s.res = p[1] as Int; s.sharp = p[2] as Float; s.smooth = p[3] as Float }.padding(16.dp)) { Text(p[0] as String, color = Color.White, fontWeight = FontWeight.Bold); Text("${p[1]}p", color = A2, fontSize = 12.sp) }
            }
        }
        Go("UPSCALE KARO", s.video != null && !s.busy) { run(ctx, s, 2) }
        Status(s)
    }
}

@Composable fun ShPage(s: St, back: () -> Unit) {
    val ctx = LocalContext.current
    Page("Shorts", back) {
        Pick(s)
        Go("30 SEC KE SHORTS BANAO", s.video != null && !s.busy) { run(ctx, s, 1) }
        Status(s)
        if (s.shorts.isNotEmpty()) Text("Tap karke play karo • pasand ho to Save, nahi to Delete", color = Color.Gray, fontSize = 12.sp)
        s.shorts.toList().chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { f ->
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.fillMaxWidth(), Alignment.Center) { Player9(Uri.fromFile(f), 240, false) }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Chip("💾 Save", Modifier.weight(1f)) { save(ctx, f); s.shorts.remove(f) }
                            Chip("🗑 Delete", Modifier.weight(1f)) { f.delete(); s.shorts.remove(f) }
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable fun Anim(s: St) {
    val a by rememberInfiniteTransition(label = "r").animateFloat(0f, 360f, infiniteRepeatable(tween(1500, easing = LinearEasing)), label = "a")
    val p by rememberInfiniteTransition(label = "p").animateFloat(0.92f, 1.06f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "p")
    Box(Modifier.fillMaxSize().background(Color(0xEE05060C)).clickable(enabled = false) {}, Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(230.dp), Alignment.Center) {
                Canvas(Modifier.fillMaxSize().padding(8.dp).rotate(a)) { drawArc(brush = Brush.sweepGradient(listOf(A1, A2, A3, A1)), startAngle = 0f, sweepAngle = 280f, useCenter = false, style = Stroke(width = 10f, cap = StrokeCap.Round)) }
                s.thumb?.let { Image(it.asImageBitmap(), null, Modifier.size(180.dp).scale(p).clip(CircleShape), contentScale = ContentScale.Crop) }
            }
            Spacer(Modifier.height(20.dp)); Text(s.status, color = A2, fontWeight = FontWeight.Bold)
        }
    }
}

class Cap(val t: String, val k: Int) : TextOverlay() {
    override fun getText(p: Long): SpannableString {
        val st = sty[k]; val sp = SpannableString(t.ifBlank { " " }); val n = sp.length
        sp.setSpan(ForegroundColorSpan(st.second.toInt()), 0, n, 0)
        if (st.third != 0L) sp.setSpan(BackgroundColorSpan(st.third.toInt()), 0, n, 0)
        sp.setSpan(AbsoluteSizeSpan(56), 0, n, 0)
        return sp
    }
    override fun getOverlaySettings(p: Long) = OverlaySettings.Builder().setBackgroundFrameAnchor(0f, -0.7f).build()
}

fun save(c: Context, f: File) {
    val v = ContentValues().apply { put(MediaStore.Video.Media.DISPLAY_NAME, "ZXC_${System.currentTimeMillis()}.mp4"); put(MediaStore.Video.Media.MIME_TYPE, "video/mp4"); put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ZXC") }
    c.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)?.let { u -> c.contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } } }
    f.delete()
}

fun run(c: Context, s: St, mode: Int) { s.busy = true; export(c, s, mode) { s.busy = false } }

fun export(ctx: Context, s: St, mode: Int, done: () -> Unit) {
    val video = s.video!!
    val mr = MediaMetadataRetriever().apply { setDataSource(ctx, video) }
    val dur = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toLong(); mr.release()
    val seg = if (mode == 1) 30000L else dur
    val n = ((dur + seg - 1) / seg).toInt()
    fun go(i: Int) {
        if (i >= n) { s.status = if (mode == 1) "Done ✅ $n short ready, Shorts page pe dekho" else "Done ✅ Movies/ZXC me save"; done(); return }
        s.status = "Processing ${i + 1}/$n …"
        val clip = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(i * seg).setEndPositionMs(minOf(dur, (i + 1) * seg)).build()
        val item = MediaItem.Builder().setUri(video).setClippingConfiguration(clip).build()
        val fx = tplFx(s.tpl).toMutableList()
        if (mode == 0) fx.add(OverlayEffect(ImmutableList.of<TextureOverlay>(Cap(s.text, s.style))))
        if (mode == 1) fx.add(Presentation.createForAspectRatio(9f / 16f, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
        if (mode == 2) { fx.add(Presentation.createForHeight(s.res)); if (s.sharp > 0f) fx.add(Contrast(s.sharp * 0.4f)) }
        val out = File(ctx.cacheDir, "zxc_${System.currentTimeMillis()}.mp4")
        val t = Transformer.Builder(ctx).setVideoMimeType(MimeTypes.VIDEO_H264).addListener(object : Transformer.Listener {
            override fun onCompleted(c: Composition, r: ExportResult) { if (mode == 1) s.shorts.add(out) else save(ctx, out); go(i + 1) }
            override fun onError(c: Composition, r: ExportResult, e: ExportException) { s.status = "Error: ${e.message}"; done() }
        }).build()
        t.start(EditedMediaItem.Builder(item).setEffects(Effects(emptyList(), fx)).build(), out.path)
    }
    go(0)
}
