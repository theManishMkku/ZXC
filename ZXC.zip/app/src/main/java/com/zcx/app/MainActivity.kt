package com.zcx.app

import android.content.ContentValues
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.SpannableString
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts.GetContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.*
import androidx.media3.effect.*
import androidx.media3.transformer.*
import com.google.common.collect.ImmutableList
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

val Bg = Color(0xFF0A0B14); val Card = Color(0xFF151728); val A1 = Color(0xFF7C5CFF); val A2 = Color(0xFF00E5FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s); enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = A1, background = Bg, surface = Card)) {
                var splash by remember { mutableStateOf(true) }
                if (splash) Splash { splash = false } else Home()
            }
        }
    }
}

@Composable fun Splash(done: () -> Unit) {
    val s = remember { Animatable(0.5f) }; val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { launch { s.animateTo(1f, spring(0.45f)) }; a.animateTo(1f, tween(700)); delay(900); done() }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF241552), Bg))), Alignment.Center) {
        Column(Modifier.scale(s.value).alpha(a.value), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("ZXC", style = TextStyle(brush = Brush.linearGradient(listOf(A1, A2)), fontSize = 72.sp, fontWeight = FontWeight.Black))
            Text("CAPTIONS • SHORTS • UPSCALE", color = Color.Gray, fontSize = 11.sp, letterSpacing = 3.sp)
        }
    }
}

@Composable fun Home() {
    var tab by remember { mutableIntStateOf(0) }
    val names = listOf("Captions", "Shorts", "Upscale"); val icons = listOf("💬", "✂️", "⬆️")
    Scaffold(containerColor = Bg, bottomBar = {
        NavigationBar(containerColor = Card) {
            names.forEachIndexed { i, n -> NavigationBarItem(tab == i, { tab = i }, { Text(icons[i], fontSize = 20.sp) }, label = { Text(n) }) }
        }
    }) { p ->
        Column(Modifier.padding(p).padding(20.dp)) {
            Text("ZXC", style = TextStyle(brush = Brush.linearGradient(listOf(A1, A2)), fontSize = 34.sp, fontWeight = FontWeight.Black))
            Spacer(Modifier.height(16.dp))
            Tool(tab)
        }
    }
}

@Composable fun Tool(mode: Int) {
    val ctx = LocalContext.current
    var video by remember(mode) { mutableStateOf<Uri?>(null) }
    var srt by remember(mode) { mutableStateOf<Uri?>(null) }
    var h by remember { mutableIntStateOf(1080) }
    var status by remember(mode) { mutableStateOf("") }
    var busy by remember(mode) { mutableStateOf(false) }
    val pv = rememberLauncherForActivityResult(GetContent()) { video = it }
    val ps = rememberLauncherForActivityResult(GetContent()) { srt = it }
    val info = listOf("Video + .srt file do, captions video me burn ho jayenge", "Lambi video ko 30 sec ke 9:16 shorts me kaato", "Video ko 1080p / 1440p / 4K me upscale karo")
    Column(Modifier.background(Card, RoundedCornerShape(24.dp)).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(info[mode], color = Color.LightGray)
        Pill(if (video == null) "📁  Video chuno" else "✅  Video ready") { pv.launch("video/*") }
        if (mode == 0) Pill(if (srt == null) "📝  SRT chuno" else "✅  SRT ready") { ps.launch("*/*") }
        if (mode == 2) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(1080, 1440, 2160).forEach { r -> FilterChip(h == r, { h = r }, { Text(if (r == 2160) "4K" else "${r}p") }) }
        }
        val ok = video != null && (mode != 0 || srt != null) && !busy
        Box(Modifier.fillMaxWidth().alpha(if (ok) 1f else 0.4f).background(Brush.horizontalGradient(listOf(A1, A2)), RoundedCornerShape(16.dp))
            .clickable(enabled = ok) { busy = true; export(ctx, video!!, mode, srt, h, { status = it }) { busy = false } }.padding(16.dp), Alignment.Center) {
            Text(if (busy) "Processing…" else "START", fontWeight = FontWeight.Bold, color = Color.White)
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = A2)
        if (status.isNotEmpty()) Text(status, color = A2)
    }
}

@Composable fun Pill(t: String, c: () -> Unit) = Box(Modifier.fillMaxWidth().background(Color(0xFF1F2238), RoundedCornerShape(16.dp)).clickable { c() }.padding(16.dp)) { Text(t, color = Color.White) }

class Cap(val l: List<Triple<Long, Long, String>>) : TextOverlay() {
    override fun getText(t: Long): SpannableString {
        val s = l.firstOrNull { t / 1000 in it.first..it.second }?.third ?: " "
        return SpannableString(s).apply {
            setSpan(ForegroundColorSpan(android.graphics.Color.WHITE), 0, s.length, 0)
            setSpan(AbsoluteSizeSpan(52), 0, s.length, 0)
        }
    }
    override fun getOverlaySettings(t: Long) = OverlaySettings.Builder().setBackgroundFrameAnchor(0f, -0.75f).build()
}

fun ms(s: String): Long { val (h, m, x) = s.trim().split(":"); val (sec, mi) = x.split(","); return ((h.toLong() * 60 + m.toLong()) * 60 + sec.toLong()) * 1000 + mi.toLong() }
fun parseSrt(c: Context, u: Uri) = c.contentResolver.openInputStream(u)!!.bufferedReader().readText().replace("\r", "").trim().split("\n\n").mapNotNull { b ->
    val l = b.lines(); val i = l.indexOfFirst { "-->" in it }
    if (i < 0) null else { val (a, z) = l[i].split("-->"); Triple(ms(a), ms(z), l.drop(i + 1).joinToString("\n")) }
}

fun save(c: Context, f: File) {
    val v = ContentValues().apply { put(MediaStore.Video.Media.DISPLAY_NAME, "ZXC_${System.currentTimeMillis()}.mp4"); put(MediaStore.Video.Media.MIME_TYPE, "video/mp4"); put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ZXC") }
    c.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)?.let { u -> c.contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } } }
    f.delete()
}

fun export(ctx: Context, video: Uri, mode: Int, srt: Uri?, h: Int, say: (String) -> Unit, done: () -> Unit) {
    val mr = MediaMetadataRetriever().apply { setDataSource(ctx, video) }
    val dur = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toLong(); mr.release()
    val seg = if (mode == 1) 30000L else dur
    val n = ((dur + seg - 1) / seg).toInt()
    fun go(i: Int) {
        if (i >= n) { say("Done ✅ $n file Movies/ZXC me save"); done(); return }
        say("Processing ${i + 1}/$n …")
        val clip = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(i * seg).setEndPositionMs(minOf(dur, (i + 1) * seg)).build()
        val item = MediaItem.Builder().setUri(video).setClippingConfiguration(clip).build()
        val fx: List<Effect> = when (mode) {
            0 -> listOf(OverlayEffect(ImmutableList.of<TextureOverlay>(Cap(parseSrt(ctx, srt!!)))))
            1 -> listOf(Presentation.createForAspectRatio(9f / 16f, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
            else -> listOf(Presentation.createForHeight(h))
        }
        val out = File(ctx.cacheDir, "zcx_${System.currentTimeMillis()}.mp4")
        val t = Transformer.Builder(ctx).setVideoMimeType(MimeTypes.VIDEO_H264).addListener(object : Transformer.Listener {
            override fun onCompleted(c: Composition, r: ExportResult) { save(ctx, out); go(i + 1) }
            override fun onError(c: Composition, r: ExportResult, e: ExportException) { say("Error: ${e.message}"); done() }
        }).build()
        t.start(EditedMediaItem.Builder(item).setEffects(Effects(emptyList(), fx)).build(), out.path)
    }
    go(0)
}
